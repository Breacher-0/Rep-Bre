import React from 'react';
import { motion } from 'framer-motion';
import { FileText } from 'lucide-react';

const Transcript = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-neutral-900 dark:text-neutral-100">
          Academic Transcript
        </h1>
      </div>

      <div className="card">
        <div className="flex items-center space-x-3 mb-4">
          <FileText className="w-6 h-6 text-accent-600 dark:text-accent-400" />
          <h2 className="text-xl font-semibold text-neutral-900 dark:text-neutral-100">
            Official Transcript
          </h2>
        </div>
        <p className="text-neutral-600 dark:text-neutral-400">
          View your complete academic record, including all courses taken and grades received.
        </p>
      </div>
    </motion.div>
  );
};

export default Transcript;