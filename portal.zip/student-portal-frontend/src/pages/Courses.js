import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen } from 'lucide-react';

const Courses = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-neutral-900 dark:text-neutral-100">
          Course Management
        </h1>
      </div>

      <div className="card">
        <div className="flex items-center space-x-3 mb-4">
          <BookOpen className="w-6 h-6 text-primary-600 dark:text-primary-400" />
          <h2 className="text-xl font-semibold text-neutral-900 dark:text-neutral-100">
            Course Enrollment
          </h2>
        </div>
        <p className="text-neutral-600 dark:text-neutral-400">
          Browse available courses, view course details, and manage your enrollments.
        </p>
      </div>
    </motion.div>
  );
};

export default Courses;