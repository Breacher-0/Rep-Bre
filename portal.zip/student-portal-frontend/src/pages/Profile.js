import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { User, Mail, Phone, MapPin, Calendar, Award } from 'lucide-react';
import apiService from '../services/apiService';
import LoadingSpinner from '../components/LoadingSpinner';
import { toast } from 'react-toastify';

const Profile = () => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({});

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      const data = await apiService.getStudentProfile();
      setProfile(data);
      setFormData({
        phone: data.phone || '',
        address: data.address || '',
        major: data.major || ''
      });
    } catch (err) {
      console.error('Error fetching profile:', err);
      toast.error('Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async () => {
    try {
      await apiService.updateStudentProfile(formData);
      toast.success('Profile updated successfully');
      setEditing(false);
      fetchProfile();
    } catch (err) {
      console.error('Error updating profile:', err);
      toast.error('Failed to update profile');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <LoadingSpinner text="Loading profile..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <h1 className="text-3xl font-bold text-neutral-900 dark:text-neutral-100">
          Student Profile
        </h1>
        {!editing && (
          <button
            onClick={() => setEditing(true)}
            className="btn-outline"
          >
            Edit Profile
          </button>
        )}
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Information */}
        <div className="lg:col-span-2">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="card"
          >
            <div className="flex items-center space-x-4 mb-6">
              <div className="w-16 h-16 bg-gradient-to-r from-primary-600 to-secondary-600 rounded-full flex items-center justify-center">
                <User className="w-8 h-8 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-neutral-900 dark:text-neutral-100">
                  {profile.fullName}
                </h2>
                <p className="text-neutral-600 dark:text-neutral-400">
                  {profile.studentNumber}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="form-label">Full Name</label>
                <input
                  type="text"
                  value={profile.fullName}
                  disabled
                  className="input-field bg-neutral-100 dark:bg-neutral-700 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="form-label">Email</label>
                <input
                  type="email"
                  value={profile.email}
                  disabled
                  className="input-field bg-neutral-100 dark:bg-neutral-700 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="form-label">Phone</label>
                <input
                  type="tel"
                  value={editing ? formData.phone : profile.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  disabled={!editing}
                  className={`input-field ${editing ? '' : 'bg-neutral-100 dark:bg-neutral-700 cursor-not-allowed'}`}
                />
              </div>

              <div>
                <label className="form-label">Major</label>
                <input
                  type="text"
                  value={editing ? formData.major : profile.major}
                  onChange={(e) => setFormData({...formData, major: e.target.value})}
                  disabled={!editing}
                  className={`input-field ${editing ? '' : 'bg-neutral-100 dark:bg-neutral-700 cursor-not-allowed'}`}
                />
              </div>

              <div className="md:col-span-2">
                <label className="form-label">Address</label>
                <input
                  type="text"
                  value={editing ? formData.address : profile.address}
                  onChange={(e) => setFormData({...formData, address: e.target.value})}
                  disabled={!editing}
                  className={`input-field ${editing ? '' : 'bg-neutral-100 dark:bg-neutral-700 cursor-not-allowed'}`}
                />
              </div>
            </div>

            {editing && (
              <div className="flex space-x-3 mt-6">
                <button
                  onClick={handleUpdate}
                  className="btn-primary"
                >
                  Save Changes
                </button>
                <button
                  onClick={() => {
                    setEditing(false);
                    setFormData({
                      phone: profile.phone || '',
                      address: profile.address || '',
                      major: profile.major || ''
                    });
                  }}
                  className="btn-outline"
                >
                  Cancel
                </button>
              </div>
            )}
          </motion.div>
        </div>

        {/* Academic Information */}
        <div className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="card"
          >
            <h3 className="text-lg font-semibold text-neutral-900 dark:text-neutral-100 mb-4">
              Academic Information
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-neutral-600 dark:text-neutral-400">Current GPA</span>
                <span className="font-semibold text-neutral-900 dark:text-neutral-100">
                  {profile.gpa.toFixed(2)}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-neutral-600 dark:text-neutral-400">Academic Standing</span>
                <span className="font-semibold text-primary-600 dark:text-primary-400">
                  {profile.academicStanding}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-neutral-600 dark:text-neutral-400">Credits Completed</span>
                <span className="font-semibold text-neutral-900 dark:text-neutral-100">
                  {profile.creditsCompleted}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-neutral-600 dark:text-neutral-400">Enrollment Date</span>
                <span className="font-semibold text-neutral-900 dark:text-neutral-100">
                  {new Date(profile.enrollmentDate).toLocaleDateString()}
                </span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="card"
          >
            <h3 className="text-lg font-semibold text-neutral-900 dark:text-neutral-100 mb-4">
              Quick Stats
            </h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-primary-50 dark:bg-primary-900/20 rounded-lg">
                <Award className="w-8 h-8 text-primary-600 dark:text-primary-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-primary-600 dark:text-primary-400">
                  {profile.gpa.toFixed(2)}
                </p>
                <p className="text-xs text-neutral-600 dark:text-neutral-400">
                  GPA
                </p>
              </div>
              
              <div className="text-center p-4 bg-secondary-50 dark:bg-secondary-900/20 rounded-lg">
                <BookOpen className="w-8 h-8 text-secondary-600 dark:text-secondary-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-secondary-600 dark:text-secondary-400">
                  {profile.creditsCompleted}
                </p>
                <p className="text-xs text-neutral-600 dark:text-neutral-400">
                  Credits
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Profile;