import axios from 'axios';
import authService from './authService';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

class ApiService {
  constructor() {
    this.api = axios.create({
      baseURL: API_URL,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.setupInterceptors();
  }

  setupInterceptors() {
    // Request interceptor to add auth token
    this.api.interceptors.request.use(
      (config) => {
        const token = authService.getToken();
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // Response interceptor for error handling
    this.api.interceptors.response.use(
      (response) => {
        return response;
      },
      (error) => {
        if (error.response?.status === 401) {
          authService.logout();
          window.location.href = '/login';
        }
        return Promise.reject(error);
      }
    );
  }

  // Student API calls
  async getStudentProfile() {
    try {
      const response = await this.api.get('/students/profile');
      return response.data;
    } catch (error) {
      console.error('Error fetching student profile:', error);
      throw error;
    }
  }

  async updateStudentProfile(profileData) {
    try {
      const response = await this.api.put('/students/profile', profileData);
      return response.data;
    } catch (error) {
      console.error('Error updating student profile:', error);
      throw error;
    }
  }

  async getStudentDashboard() {
    try {
      const response = await this.api.get('/students/dashboard');
      return response.data;
    } catch (error) {
      console.error('Error fetching student dashboard:', error);
      throw error;
    }
  }

  async getStudentTranscript() {
    try {
      const response = await this.api.get('/students/transcript');
      return response.data;
    } catch (error) {
      console.error('Error fetching student transcript:', error);
      throw error;
    }
  }

  // Course API calls
  async getCourses(filters = {}) {
    try {
      const params = new URLSearchParams();
      if (filters.semester) params.append('semester', filters.semester);
      if (filters.department) params.append('department', filters.department);
      
      const response = await this.api.get(`/courses?${params.toString()}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching courses:', error);
      throw error;
    }
  }

  async getCourse(courseId) {
    try {
      const response = await this.api.get(`/courses/${courseId}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching course:', error);
      throw error;
    }
  }

  async enrollInCourse(courseId) {
    try {
      const response = await this.api.post(`/courses/${courseId}/enroll`);
      return response.data;
    } catch (error) {
      console.error('Error enrolling in course:', error);
      throw error;
    }
  }

  async dropCourse(courseId) {
    try {
      const response = await this.api.delete(`/courses/${courseId}/enroll`);
      return response.data;
    } catch (error) {
      console.error('Error dropping course:', error);
      throw error;
    }
  }

  async getMyCourses() {
    try {
      const response = await this.api.get('/courses/my-courses');
      return response.data;
    } catch (error) {
      console.error('Error fetching my courses:', error);
      throw error;
    }
  }

  async getDepartments() {
    try {
      const response = await this.api.get('/courses/departments');
      return response.data;
    } catch (error) {
      console.error('Error fetching departments:', error);
      throw error;
    }
  }

  async getSemesters() {
    try {
      const response = await this.api.get('/courses/semesters');
      return response.data;
    } catch (error) {
      console.error('Error fetching semesters:', error);
      throw error;
    }
  }

  // Grade API calls
  async getGrades(filters = {}) {
    try {
      const params = new URLSearchParams();
      if (filters.courseId) params.append('courseId', filters.courseId);
      if (filters.semester) params.append('semester', filters.semester);
      
      const response = await this.api.get(`/grades?${params.toString()}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching grades:', error);
      throw error;
    }
  }

  async getCourseGrades(courseId) {
    try {
      const response = await this.api.get(`/grades/course/${courseId}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching course grades:', error);
      throw error;
    }
  }

  async getGradeSummary() {
    try {
      const response = await this.api.get('/grades/summary');
      return response.data;
    } catch (error) {
      console.error('Error fetching grade summary:', error);
      throw error;
    }
  }

  async getRecentGrades(count = 5) {
    try {
      const response = await this.api.get(`/grades/recent?count=${count}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching recent grades:', error);
      throw error;
    }
  }
}

export default new ApiService();