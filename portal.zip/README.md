# Student Portal - Full-Stack Web Application

A comprehensive student management portal built with ASP.NET Core Web API backend and React frontend. This application provides students with the ability to manage their academic journey including profile management, course enrollment, and grade tracking.

## 🌟 Features

### Student Features
- **User Authentication**: Secure login with JWT tokens
- **Profile Management**: View and update personal information
- **Course Enrollment**: Browse and enroll in available courses
- **Grade Tracking**: View grades and academic performance
- **Transcript Generation**: Complete academic record
- **Responsive Design**: Works on all devices

### Technical Features
- **Modern UI**: Clean, minimalistic design with smooth animations
- **Dark/Light Mode**: Theme switching capability
- **Real-time Updates**: Live data synchronization
- **Form Validation**: Client and server-side validation
- **Error Handling**: Comprehensive error management
- **Loading States**: Smooth loading indicators

## 🛠 Technology Stack

### Backend (ASP.NET Core)
- **Framework**: .NET 8.0
- **Database**: Entity Framework Core with SQL Server
- **Authentication**: JWT Bearer Tokens
- **API**: RESTful Web API
- **Security**: BCrypt password hashing
- **Documentation**: Swagger/OpenAPI

### Frontend (React)
- **Framework**: React 18.2.0
- **Styling**: Tailwind CSS
- **Animations**: Framer Motion
- **Routing**: React Router DOM
- **HTTP Client**: Axios
- **Notifications**: React Toastify
- **Icons**: Lucide React

### Database
- **Type**: Microsoft SQL Server
- **ORM**: Entity Framework Core
- **Migration**: Code-first approach
- **Backup**: .BAK file included

## 📁 Project Structure

```
student-portal/
├── student-portal-backend/          # ASP.NET Core Web API
│   ├── Controllers/                 # API Controllers
│   ├── Models/                     # Data Models
│   ├── Services/                   # Business Logic
│   ├── Data/                       # Database Context
│   ├── Program.cs                  # Application Entry
│   ├── appsettings.json            # Configuration
│   └── StudentPortal.csproj        # Project File
│
├── student-portal-frontend/         # React Frontend
│   ├── src/
│   │   ├── components/             # Reusable Components
│   │   ├── pages/                  # Page Components
│   │   ├── services/               # API Services
│   │   ├── context/                # React Context
│   │   ├── utils/                  # Utility Functions
│   │   └── assets/                 # Static Assets
│   ├── public/                     # Public Files
│   ├── package.json                # Dependencies
│   └── tailwind.config.js          # Tailwind Configuration
│
├── StudentPortalDB.bak             # Database Backup
└── README.md                       # Documentation
```

## 🚀 Getting Started

### Prerequisites
- **.NET 8.0 SDK** - [Download here](https://dotnet.microsoft.com/download/dotnet/8.0)
- **Node.js 18+** - [Download here](https://nodejs.org/)
- **SQL Server** - [Download here](https://www.microsoft.com/sql-server/sql-server-downloads)
- **Visual Studio 2022** or **Visual Studio Code**

### Installation Steps

#### 1. Clone the Repository
```bash
git clone https://github.com/yourusername/student-portal.git
cd student-portal
```

#### 2. Setup Database

**Option A: Restore from Backup**
```sql
-- Open SQL Server Management Studio (SSMS)
-- Restore the StudentPortalDB.bak file
-- The database will be created with sample data
```

**Option B: Create New Database**
```sql
-- Create a new database named "StudentPortalDB"
CREATE DATABASE StudentPortalDB;
```

#### 3. Configure Backend

**Update Connection String**
```json
// student-portal-backend/appsettings.json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=YOUR_SERVER_NAME;Database=StudentPortalDB;Trusted_Connection=True;MultipleActiveResultSets=true"
  },
  "Jwt": {
    "Secret": "your-very-secure-secret-key-here-make-it-long-and-random",
    "Issuer": "student-portal",
    "Audience": "student-portal-users"
  }
}
```

**Install Dependencies**
```bash
cd student-portal-backend
dotnet restore
```

**Run Database Migrations**
```bash
dotnet ef database update
```

**Start the Backend**
```bash
dotnet run
```

The API will be available at `https://localhost:5000` or `http://localhost:5000`

#### 4. Configure Frontend

**Install Dependencies**
```bash
cd student-portal-frontend
npm install
```

**Update API URL (if needed)**
```javascript
// student-portal-frontend/src/services/apiService.js
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
```

**Start the Frontend**
```bash
npm start
```

The frontend will be available at `http://localhost:3000`

## 🔐 Demo Credentials

The application comes with pre-populated demo data:

### Student Accounts
- **Email**: `john.doe@university.edu`
- **Password**: `password123`
- **Student Number**: `STU2024001`

- **Email**: `jane.smith@university.edu`
- **Password**: `password123`
- **Student Number**: `STU2024002`

### Sample Courses
- **CS101**: Introduction to Computer Science
- **CS201**: Data Structures and Algorithms
- **MATH150**: Calculus I
- **ENG101**: English Composition

## 📱 Usage Guide

### Login
1. Navigate to `http://localhost:3000`
2. Use one of the demo credentials above
3. Click "Sign In" to access the portal

### Dashboard
- View your current GPA and academic standing
- See enrolled courses and recent grades
- Quick access to all portal features

### Profile Management
- View personal and academic information
- Update contact details (phone, address)
- Change major designation

### Course Enrollment
- Browse available courses by semester
- View course details and prerequisites
- Enroll in or drop courses

### Grade Tracking
- View grades by course or semester
- Track academic progress
- View detailed grade breakdowns

### Transcript
- Generate complete academic record
- View semester-by-semester breakdown
- Track overall academic progress

## 🎨 Design Features

### Modern UI/UX
- **Minimalistic Design**: Clean, uncluttered interface
- **Soft Color Palette**: Easy on the eyes with professional appearance
- **Rounded Elements**: Modern, friendly design language
- **Consistent Typography**: Clear hierarchy and readability

### Animations & Interactions
- **Smooth Transitions**: Fade-in animations for all elements
- **Loading States**: Elegant loading indicators
- **Hover Effects**: Interactive button and card states
- **Form Validation**: Real-time feedback and error handling

### Responsive Design
- **Mobile-First**: Optimized for all screen sizes
- **Flexible Layout**: Adapts to different devices
- **Touch-Friendly**: Large buttons and touch targets
- **Accessibility**: WCAG compliant color contrast

## 🔧 API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/refresh` - Refresh JWT token
- `POST /api/auth/logout` - User logout
- `GET /api/auth/me` - Get current user

### Students
- `GET /api/students/profile` - Get student profile
- `PUT /api/students/profile` - Update student profile
- `GET /api/students/dashboard` - Get dashboard data
- `GET /api/students/transcript` - Get academic transcript

### Courses
- `GET /api/courses` - Get available courses
- `GET /api/courses/{id}` - Get course details
- `POST /api/courses/{id}/enroll` - Enroll in course
- `DELETE /api/courses/{id}/enroll` - Drop course
- `GET /api/courses/my-courses` - Get enrolled courses

### Grades
- `GET /api/grades` - Get student grades
- `GET /api/grades/course/{id}` - Get course grades
- `GET /api/grades/summary` - Get grade summary
- `GET /api/grades/recent` - Get recent grades

## 🛡 Security Features

### Authentication
- **JWT Tokens**: Secure stateless authentication
- **Token Refresh**: Automatic token renewal
- **Password Hashing**: BCrypt encryption
- **Session Management**: Secure session handling

### Authorization
- **Role-Based Access**: Student-specific permissions
- **Protected Routes**: API endpoint security
- **CORS Configuration**: Cross-origin request control
- **Input Validation**: Server-side data validation

### Data Protection
- **SQL Injection Prevention**: Parameterized queries
- **XSS Protection**: Input sanitization
- **HTTPS Support**: Secure communication
- **Data Encryption**: Sensitive information protection

## 🚀 Deployment

### Production Deployment

#### Backend Deployment
1. **Publish the Application**
```bash
dotnet publish -c Release -o ./publish
```

2. **Configure Production Settings**
```json
// appsettings.Production.json
{
  "ConnectionStrings": {
    "DefaultConnection": "Your_Production_Connection_String"
  },
  "Jwt": {
    "Secret": "Your_Production_Secret_Key"
  }
}
```

3. **Deploy to Server**
- Use IIS, Azure, or Linux hosting
- Configure SSL certificate
- Set up environment variables

#### Frontend Deployment
1. **Build the Application**
```bash
npm run build
```

2. **Deploy to Static Hosting**
- Netlify, Vercel, or AWS S3
- Configure custom domain
- Set up HTTPS

### Docker Deployment

#### Backend Dockerfile
```dockerfile
FROM mcr.microsoft.com/dotnet/aspnet:8.0
WORKDIR /app
COPY ./publish .
ENTRYPOINT ["dotnet", "StudentPortal.dll"]
```

#### Frontend Dockerfile
```dockerfile
FROM node:18-alpine as build
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/build /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf
```

## 🧪 Testing

### Backend Testing
```bash
# Run unit tests
dotnet test

# Run integration tests
dotnet test --filter Category=Integration
```

### Frontend Testing
```bash
# Run all tests
npm test

# Run tests in watch mode
npm test -- --watch

# Generate coverage report
npm test -- --coverage
```

## 📊 Database Schema

### Students Table
- StudentId (PK, int)
- FirstName (nvarchar)
- LastName (nvarchar)
- Email (nvarchar, unique)
- StudentNumber (nvarchar, unique)
- Phone (nvarchar)
- DateOfBirth (datetime)
- Address (nvarchar)
- EnrollmentDate (datetime)
- Major (nvarchar)
- GPA (decimal)
- CreditsCompleted (int)
- Status (nvarchar)
- PasswordHash (nvarchar)
- RefreshToken (nvarchar)
- RefreshTokenExpiryTime (datetime)
- Role (nvarchar)

### Courses Table
- CourseId (PK, int)
- CourseCode (nvarchar, unique)
- CourseName (nvarchar)
- Description (nvarchar)
- Department (nvarchar)
- Instructor (nvarchar)
- Credits (int)
- MaxCapacity (int)
- CurrentEnrollment (int)
- Schedule (nvarchar)
- Location (nvarchar)
- StartDate (datetime)
- EndDate (datetime)
- Semester (nvarchar)
- Status (nvarchar)
- Prerequisites (decimal)

### Enrollments Table
- EnrollmentId (PK, int)
- StudentId (FK, int)
- CourseId (FK, int)
- EnrollmentDate (datetime)
- Status (nvarchar)
- MidtermGrade (decimal)
- FinalGrade (decimal)

### Grades Table
- GradeId (PK, int)
- StudentId (FK, int)
- CourseId (FK, int)
- AssignmentType (nvarchar)
- AssignmentName (nvarchar)
- Score (decimal)
- MaxScore (decimal)
- Weight (decimal)
- DateGraded (datetime)
- Feedback (nvarchar)

## 🔍 Troubleshooting

### Common Issues

#### Database Connection
```bash
# Check SQL Server service
sc query MSSQLSERVER

# Test connection
dotnet ef database update
```

#### CORS Issues
```javascript
// Ensure CORS is properly configured in Program.cs
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowReactApp",
        policy =>
        {
            policy.WithOrigins("http://localhost:3000")
                  .AllowAnyHeader()
                  .AllowAnyMethod()
                  .AllowCredentials();
        });
});
```

#### JWT Authentication
```bash
# Check JWT configuration
# Ensure secret key is at least 32 characters
# Verify issuer and audience settings
```

### Performance Optimization

#### Backend
- Enable response compression
- Implement caching with Redis
- Use async/await patterns
- Optimize database queries

#### Frontend
- Implement code splitting
- Use lazy loading for images
- Enable service worker
- Optimize bundle size

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👥 Support

For support, email support@studentportal.com or join our Slack channel.

## 🙏 Acknowledgments

- **Microsoft** for .NET and SQL Server
- **React Team** for the amazing frontend framework
- **Tailwind CSS** for the utility-first CSS framework
- **Lucide** for the beautiful icon library
- **All contributors** who helped make this project possible

---

**Built with ❤️ by the Student Portal Team**