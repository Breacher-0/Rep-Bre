using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentPortal.Data;
using StudentPortal.Models;
using StudentPortal.Services;

namespace StudentPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class StudentsController : ControllerBase
    {
        private readonly StudentPortalContext _context;
        private readonly IAuthService _authService;
        private readonly ILogger<StudentsController> _logger;

        public StudentsController(StudentPortalContext context, IAuthService authService, ILogger<StudentsController> logger)
        {
            _context = context;
            _authService = authService;
            _logger = logger;
        }

        [HttpGet("profile")]
        public async Task<IActionResult> GetProfile()
        {
            try
            {
                var currentUser = await _authService.GetCurrentUserAsync(User);
                if (currentUser == null)
                {
                    return NotFound(new { message = "User not found" });
                }

                var student = await _context.Students
                    .Where(s => s.StudentId == currentUser.StudentId)
                    .Select(s => new
                    {
                        s.StudentId,
                        s.FirstName,
                        s.LastName,
                        s.Email,
                        s.StudentNumber,
                        s.Phone,
                        s.DateOfBirth,
                        s.Address,
                        s.EnrollmentDate,
                        s.Major,
                        s.GPA,
                        s.CreditsCompleted,
                        s.Status,
                        AcademicStanding = s.AcademicStanding,
                        FullName = s.FullName
                    })
                    .FirstOrDefaultAsync();

                if (student == null)
                {
                    return NotFound(new { message = "Student not found" });
                }

                return Ok(student);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting student profile");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }

        [HttpPut("profile")]
        public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileRequest request)
        {
            try
            {
                var currentUser = await _authService.GetCurrentUserAsync(User);
                if (currentUser == null)
                {
                    return NotFound(new { message = "User not found" });
                }

                var student = await _context.Students.FindAsync(currentUser.StudentId);
                if (student == null)
                {
                    return NotFound(new { message = "Student not found" });
                }

                // Update allowed fields
                student.Phone = request.Phone ?? student.Phone;
                student.Address = request.Address ?? student.Address;
                student.Major = request.Major ?? student.Major;

                await _context.SaveChangesAsync();

                return Ok(new 
                { 
                    message = "Profile updated successfully",
                    student = new 
                    {
                        student.StudentId,
                        student.FirstName,
                        student.LastName,
                        student.Email,
                        student.Phone,
                        student.Address,
                        student.Major
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating student profile");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }

        [HttpGet("dashboard")]
        public async Task<IActionResult> GetDashboard()
        {
            try
            {
                var currentUser = await _authService.GetCurrentUserAsync(User);
                if (currentUser == null)
                {
                    return NotFound(new { message = "User not found" });
                }

                var student = await _context.Students
                    .Include(s => s.Enrollments)
                    .ThenInclude(e => e.Course)
                    .Include(s => s.Grades)
                    .FirstOrDefaultAsync(s => s.StudentId == currentUser.StudentId);

                if (student == null)
                {
                    return NotFound(new { message = "Student not found" });
                }

                var currentCourses = student.Enrollments
                    .Where(e => e.Status == "Enrolled" && e.Course.EndDate >= DateTime.Now)
                    .Select(e => new
                    {
                        e.Course.CourseId,
                        e.Course.CourseCode,
                        e.Course.CourseName,
                        e.Course.Instructor,
                        e.Course.Schedule,
                        e.Course.Location,
                        e.Course.Credits
                    })
                    .ToList();

                var recentGrades = student.Grades
                    .OrderByDescending(g => g.DateGraded)
                    .Take(5)
                    .Select(g => new
                    {
                        g.Course.CourseCode,
                        g.Course.CourseName,
                        g.AssignmentType,
                        g.AssignmentName,
                        g.Score,
                        g.MaxScore,
                        g.Percentage,
                        g.LetterGrade,
                        g.DateGraded
                    })
                    .ToList();

                var semesterStats = new
                {
                    CurrentCourses = currentCourses.Count,
                    TotalCredits = currentCourses.Sum(c => c.Credits),
                    CurrentGPA = student.GPA,
                    AcademicStanding = student.AcademicStanding,
                    CreditsCompleted = student.CreditsCompleted,
                    EnrollmentDate = student.EnrollmentDate
                };

                return Ok(new
                {
                    Student = new
                    {
                        student.StudentId,
                        student.FullName,
                        student.Email,
                        student.Major,
                        student.GPA
                    },
                    CurrentCourses = currentCourses,
                    RecentGrades = recentGrades,
                    SemesterStats = semesterStats
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting student dashboard");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }

        [HttpGet("transcript")]
        public async Task<IActionResult> GetTranscript()
        {
            try
            {
                var currentUser = await _authService.GetCurrentUserAsync(User);
                if (currentUser == null)
                {
                    return NotFound(new { message = "User not found" });
                }

                var student = await _context.Students
                    .Include(s => s.Enrollments)
                    .ThenInclude(e => e.Course)
                    .Include(s => s.Grades)
                    .FirstOrDefaultAsync(s => s.StudentId == currentUser.StudentId);

                if (student == null)
                {
                    return NotFound(new { message = "Student not found" });
                }

                var transcript = student.Enrollments
                    .Where(e => e.Status == "Completed" || e.Status == "Enrolled")
                    .GroupBy(e => e.Semester)
                    .OrderByDescending(g => g.Key)
                    .Select(semester => new
                    {
                        Semester = semester.Key,
                        Courses = semester.Select(e => new
                        {
                            e.Course.CourseCode,
                            e.Course.CourseName,
                            e.Course.Credits,
                            e.Course.Instructor,
                            e.Status,
                            SemesterGrade = CalculateSemesterGrade(student.Grades.Where(g => g.CourseId == e.CourseId).ToList())
                        }).ToList(),
                        SemesterGPA = CalculateSemesterGPA(student.Grades.Where(g => 
                            semester.Any(e => e.CourseId == g.CourseId)).ToList())
                    })
                    .ToList();

                var summary = new
                {
                    TotalCredits = student.CreditsCompleted,
                    OverallGPA = student.GPA,
                    AcademicStanding = student.AcademicStanding,
                    Transcript = transcript
                };

                return Ok(summary);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting student transcript");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }

        private string CalculateSemesterGrade(List<Grade> grades)
        {
            if (grades == null || grades.Count == 0) return "N/A";
            
            var weightedScore = grades.Sum(g => g.WeightedScore);
            var totalWeight = grades.Sum(g => g.Weight);
            
            if (totalWeight == 0) return "N/A";
            
            var finalPercentage = (weightedScore / totalWeight) * 100;
            return finalPercentage switch
            {
                >= 90 => "A",
                >= 80 => "B",
                >= 70 => "C",
                >= 60 => "D",
                _ => "F"
            };
        }

        private decimal CalculateSemesterGPA(List<Grade> grades)
        {
            if (grades == null || grades.Count == 0) return 0.00m;
            
            // Group by course and calculate final grade for each course
            var courseGrades = grades
                .GroupBy(g => g.CourseId)
                .Select(g => new
                {
                    CourseId = g.Key,
                    FinalPercentage = g.Sum(grade => grade.WeightedScore) / g.Sum(grade => grade.Weight) * 100
                })
                .ToList();
            
            if (courseGrades.Count == 0) return 0.00m;
            
            // Convert to GPA points and average
            var totalGPAPoints = courseGrades.Sum(cg => PercentageToGPAPoints(cg.FinalPercentage));
            return Math.Round(totalGPAPoints / courseGrades.Count, 2);
        }

        private decimal PercentageToGPAPoints(decimal percentage)
        {
            return percentage switch
            {
                >= 90 => 4.00m,
                >= 85 => 3.67m,
                >= 80 => 3.33m,
                >= 75 => 3.00m,
                >= 70 => 2.67m,
                >= 65 => 2.33m,
                >= 60 => 2.00m,
                >= 55 => 1.67m,
                >= 50 => 1.33m,
                _ => 0.00m
            };
        }
    }

    public class UpdateProfileRequest
    {
        public string? Phone { get; set; }
        public string? Address { get; set; }
        public string? Major { get; set; }
    }
}