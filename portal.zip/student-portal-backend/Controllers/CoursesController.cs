using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentPortal.Data;
using StudentPortal.Models;
using StudentPortal.Services;

namespace StudentPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class CoursesController : ControllerBase
    {
        private readonly StudentPortalContext _context;
        private readonly IAuthService _authService;
        private readonly ILogger<CoursesController> _logger;

        public CoursesController(StudentPortalContext context, IAuthService authService, ILogger<CoursesController> logger)
        {
            _context = context;
            _authService = authService;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> GetCourses([FromQuery] string? semester = null, [FromQuery] string? department = null)
        {
            try
            {
                var query = _context.Courses.AsQueryable();

                if (!string.IsNullOrEmpty(semester))
                {
                    query = query.Where(c => c.Semester == semester);
                }

                if (!string.IsNullOrEmpty(department))
                {
                    query = query.Where(c => c.Department == department);
                }

                var courses = await query
                    .Where(c => c.Status == "Open")
                    .OrderBy(c => c.CourseCode)
                    .Select(c => new
                    {
                        c.CourseId,
                        c.CourseCode,
                        c.CourseName,
                        c.Description,
                        c.Department,
                        c.Instructor,
                        c.Credits,
                        c.MaxCapacity,
                        c.CurrentEnrollment,
                        c.AvailableSeats,
                        c.Schedule,
                        c.Location,
                        c.Semester,
                        c.Prerequisites,
                        IsFull = c.IsFull
                    })
                    .ToListAsync();

                return Ok(courses);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting courses");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetCourse(int id)
        {
            try
            {
                var course = await _context.Courses
                    .Where(c => c.CourseId == id)
                    .Select(c => new
                    {
                        c.CourseId,
                        c.CourseCode,
                        c.CourseName,
                        c.Description,
                        c.Department,
                        c.Instructor,
                        c.Credits,
                        c.MaxCapacity,
                        c.CurrentEnrollment,
                        c.AvailableSeats,
                        c.Schedule,
                        c.Location,
                        c.StartDate,
                        c.EndDate,
                        c.Semester,
                        c.Prerequisites,
                        c.Status,
                        c.IsFull
                    })
                    .FirstOrDefaultAsync();

                if (course == null)
                {
                    return NotFound(new { message = "Course not found" });
                }

                return Ok(course);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting course");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }

        [HttpPost("{id}/enroll")]
        public async Task<IActionResult> EnrollInCourse(int id)
        {
            try
            {
                var currentUser = await _authService.GetCurrentUserAsync(User);
                if (currentUser == null)
                {
                    return NotFound(new { message = "User not found" });
                }

                var course = await _context.Courses.FindAsync(id);
                if (course == null)
                {
                    return NotFound(new { message = "Course not found" });
                }

                if (course.Status != "Open")
                {
                    return BadRequest(new { message = "Course is not open for enrollment" });
                }

                if (course.IsFull)
                {
                    return BadRequest(new { message = "Course is full" });
                }

                // Check if student meets prerequisites
                if (course.Prerequisites > 0)
                {
                    var student = await _context.Students.FindAsync(currentUser.StudentId);
                    if (student == null || student.GPA < course.Prerequisites)
                    {
                        return BadRequest(new { message = "You do not meet the prerequisites for this course" });
                    }
                }

                // Check if already enrolled
                var existingEnrollment = await _context.Enrollments
                    .FirstOrDefaultAsync(e => e.StudentId == currentUser.StudentId && e.CourseId == id);

                if (existingEnrollment != null)
                {
                    return BadRequest(new { message = "You are already enrolled in this course" });
                }

                // Create enrollment
                var enrollment = new Enrollment
                {
                    StudentId = currentUser.StudentId,
                    CourseId = id,
                    EnrollmentDate = DateTime.UtcNow,
                    Status = "Enrolled"
                };

                _context.Enrollments.Add(enrollment);
                course.CurrentEnrollment++;

                await _context.SaveChangesAsync();

                return Ok(new 
                { 
                    message = "Successfully enrolled in course",
                    enrollment = new
                    {
                        enrollment.EnrollmentId,
                        enrollment.EnrollmentDate,
                        enrollment.Status,
                        Course = new
                        {
                            course.CourseCode,
                            course.CourseName,
                            course.Credits
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error enrolling in course");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }

        [HttpDelete("{id}/enroll")]
        public async Task<IActionResult> DropCourse(int id)
        {
            try
            {
                var currentUser = await _authService.GetCurrentUserAsync(User);
                if (currentUser == null)
                {
                    return NotFound(new { message = "User not found" });
                }

                var enrollment = await _context.Enrollments
                    .Include(e => e.Course)
                    .FirstOrDefaultAsync(e => e.StudentId == currentUser.StudentId && e.CourseId == id);

                if (enrollment == null)
                {
                    return NotFound(new { message = "Enrollment not found" });
                }

                if (enrollment.Status != "Enrolled")
                {
                    return BadRequest(new { message = "You are not currently enrolled in this course" });
                }

                enrollment.Status = "Dropped";
                enrollment.Course.CurrentEnrollment--;

                await _context.SaveChangesAsync();

                return Ok(new { message = "Successfully dropped course" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error dropping course");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }

        [HttpGet("my-courses")]
        public async Task<IActionResult> GetMyCourses()
        {
            try
            {
                var currentUser = await _authService.GetCurrentUserAsync(User);
                if (currentUser == null)
                {
                    return NotFound(new { message = "User not found" });
                }

                var enrollments = await _context.Enrollments
                    .Include(e => e.Course)
                    .Where(e => e.StudentId == currentUser.StudentId && e.Status == "Enrolled")
                    .Select(e => new
                    {
                        e.EnrollmentId,
                        e.EnrollmentDate,
                        e.Status,
                        e.Course.CourseId,
                        e.Course.CourseCode,
                        e.Course.CourseName,
                        e.Course.Description,
                        e.Course.Instructor,
                        e.Course.Credits,
                        e.Course.Schedule,
                        e.Course.Location,
                        e.Course.StartDate,
                        e.Course.EndDate,
                        e.Course.Semester
                    })
                    .ToListAsync();

                return Ok(enrollments);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting my courses");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }

        [HttpGet("departments")]
        public async Task<IActionResult> GetDepartments()
        {
            try
            {
                var departments = await _context.Courses
                    .Select(c => c.Department)
                    .Distinct()
                    .OrderBy(d => d)
                    .ToListAsync();

                return Ok(departments);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting departments");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }

        [HttpGet("semesters")]
        public async Task<IActionResult> GetSemesters()
        {
            try
            {
                var semesters = await _context.Courses
                    .Select(c => c.Semester)
                    .Distinct()
                    .OrderByDescending(s => s)
                    .ToListAsync();

                return Ok(semesters);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting semesters");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }
    }
}