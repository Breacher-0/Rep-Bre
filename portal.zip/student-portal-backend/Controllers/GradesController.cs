using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentPortal.Data;
using StudentPortal.Models;
using StudentPortal.Services;

namespace StudentPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class GradesController : ControllerBase
    {
        private readonly StudentPortalContext _context;
        private readonly IAuthService _authService;
        private readonly ILogger<GradesController> _logger;

        public GradesController(StudentPortalContext context, IAuthService authService, ILogger<GradesController> logger)
        {
            _context = context;
            _authService = authService;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> GetGrades([FromQuery] int? courseId = null, [FromQuery] string? semester = null)
        {
            try
            {
                var currentUser = await _authService.GetCurrentUserAsync(User);
                if (currentUser == null)
                {
                    return NotFound(new { message = "User not found" });
                }

                var query = _context.Grades
                    .Include(g => g.Course)
                    .Where(g => g.StudentId == currentUser.StudentId);

                if (courseId.HasValue)
                {
                    query = query.Where(g => g.CourseId == courseId.Value);
                }

                if (!string.IsNullOrEmpty(semester))
                {
                    query = query.Where(g => g.Course.Semester == semester);
                }

                var grades = await query
                    .OrderByDescending(g => g.DateGraded)
                    .Select(g => new
                    {
                        g.GradeId,
                        g.CourseId,
                        g.Course.CourseCode,
                        g.Course.CourseName,
                        g.Course.Semester,
                        g.AssignmentType,
                        g.AssignmentName,
                        g.Score,
                        g.MaxScore,
                        g.Weight,
                        g.Percentage,
                        g.LetterGrade,
                        g.WeightedScore,
                        g.DateGraded,
                        g.Feedback
                    })
                    .ToListAsync();

                return Ok(grades);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting grades");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }

        [HttpGet("course/{courseId}")]
        public async Task<IActionResult> GetCourseGrades(int courseId)
        {
            try
            {
                var currentUser = await _authService.GetCurrentUserAsync(User);
                if (currentUser == null)
                {
                    return NotFound(new { message = "User not found" });
                }

                var grades = await _context.Grades
                    .Include(g => g.Course)
                    .Where(g => g.StudentId == currentUser.StudentId && g.CourseId == courseId)
                    .OrderByDescending(g => g.DateGraded)
                    .Select(g => new
                    {
                        g.GradeId,
                        g.Course.CourseCode,
                        g.Course.CourseName,
                        g.AssignmentType,
                        g.AssignmentName,
                        g.Score,
                        g.MaxScore,
                        g.Weight,
                        g.Percentage,
                        g.LetterGrade,
                        g.WeightedScore,
                        g.DateGraded,
                        g.Feedback
                    })
                    .ToListAsync();

                if (grades.Count == 0)
                {
                    return NotFound(new { message = "No grades found for this course" });
                }

                var courseSummary = new
                {
                    CourseCode = grades.First().CourseCode,
                    CourseName = grades.First().CourseName,
                    CurrentGrade = CalculateCurrentGrade(grades),
                    FinalGrade = CalculateFinalGrade(grades),
                    Grades = grades
                };

                return Ok(courseSummary);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting course grades");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }

        [HttpGet("summary")]
        public async Task<IActionResult> GetGradeSummary()
        {
            try
            {
                var currentUser = await _authService.GetCurrentUserAsync(User);
                if (currentUser == null)
                {
                    return NotFound(new { message = "User not found" });
                }

                var grades = await _context.Grades
                    .Include(g => g.Course)
                    .Where(g => g.StudentId == currentUser.StudentId)
                    .ToListAsync();

                var summary = grades
                    .GroupBy(g => g.CourseId)
                    .Select(g => new
                    {
                        CourseId = g.Key,
                        CourseCode = g.First().Course.CourseCode,
                        CourseName = g.First().Course.CourseName,
                        Semester = g.First().Course.Semester,
                        FinalGrade = CalculateFinalGrade(g.ToList()),
                        TotalWeight = g.Sum(grade => grade.Weight)
                    })
                    .OrderByDescending(c => c.Semester)
                    .ToList();

                var overallStats = new
                {
                    TotalAssignments = grades.Count,
                    AverageScore = grades.Any() ? Math.Round(grades.Average(g => g.Percentage), 2) : 0,
                    CompletedCourses = summary.Count(s => s.TotalWeight >= 100),
                    CurrentGPA = currentUser.GPA
                };

                return Ok(new
                {
                    Summary = summary,
                    Statistics = overallStats
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting grade summary");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }

        [HttpGet("recent")]
        public async Task<IActionResult> GetRecentGrades([FromQuery] int count = 5)
        {
            try
            {
                var currentUser = await _authService.GetCurrentUserAsync(User);
                if (currentUser == null)
                {
                    return NotFound(new { message = "User not found" });
                }

                var grades = await _context.Grades
                    .Include(g => g.Course)
                    .Where(g => g.StudentId == currentUser.StudentId)
                    .OrderByDescending(g => g.DateGraded)
                    .Take(count)
                    .Select(g => new
                    {
                        g.GradeId,
                        g.Course.CourseCode,
                        g.Course.CourseName,
                        g.AssignmentType,
                        g.AssignmentName,
                        g.Score,
                        g.MaxScore,
                        g.Percentage,
                        g.LetterGrade,
                        g.DateGraded,
                        g.Feedback
                    })
                    .ToListAsync();

                return Ok(grades);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting recent grades");
                return StatusCode(500, new { message = "An error occurred" });
            }
        }

        private string CalculateCurrentGrade(List<Grade> grades)
        {
            if (grades == null || grades.Count == 0) return "N/A";
            
            var completedAssignments = grades.Where(g => g.Weight > 0).ToList();
            if (completedAssignments.Count == 0) return "N/A";
            
            var totalWeightedScore = completedAssignments.Sum(g => g.WeightedScore);
            var totalWeight = completedAssignments.Sum(g => g.Weight);
            
            if (totalWeight == 0) return "N/A";
            
            var currentPercentage = (totalWeightedScore / totalWeight) * 100;
            
            return currentPercentage switch
            {
                >= 90 => "A",
                >= 80 => "B",
                >= 70 => "C",
                >= 60 => "D",
                _ => "F"
            };
        }

        private string CalculateFinalGrade(List<Grade> grades)
        {
            if (grades == null || grades.Count == 0) return "N/A";
            
            var totalWeight = grades.Sum(g => g.Weight);
            if (totalWeight < 100) return "In Progress";
            
            var totalWeightedScore = grades.Sum(g => g.WeightedScore);
            var finalPercentage = (totalWeightedScore / totalWeight) * 100;
            
            return finalPercentage switch
            {
                >= 90 => "A",
                >= 80 => "B",
                >= 70 => "C",
                >= 60 => "D",
                _ => "F"
            };
        }
    }
}