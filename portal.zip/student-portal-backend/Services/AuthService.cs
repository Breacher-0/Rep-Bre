using Microsoft.IdentityModel.Tokens;
using StudentPortal.Models;
using StudentPortal.Models.Auth;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace StudentPortal.Services
{
    public interface IAuthService
    {
        Task<AuthResponse?> LoginAsync(LoginRequest request);
        Task<AuthResponse?> RefreshTokenAsync(string refreshToken);
        Task<bool> RevokeTokenAsync(string refreshToken);
        Task<Student?> GetCurrentUserAsync(ClaimsPrincipal user);
    }

    public class AuthService : IAuthService
    {
        private readonly StudentPortalContext _context;
        private readonly IConfiguration _configuration;

        public AuthService(StudentPortalContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public async Task<AuthResponse?> LoginAsync(LoginRequest request)
        {
            var student = await _context.Students
                .FirstOrDefaultAsync(s => s.Email == request.Email && s.Status == "Active");

            if (student == null || !BCrypt.Net.BCrypt.Verify(request.Password, student.PasswordHash))
            {
                return null;
            }

            var authResponse = GenerateTokens(student);
            
            // Update refresh token in database
            student.RefreshToken = authResponse.RefreshToken;
            student.RefreshTokenExpiryTime = DateTime.UtcNow.AddDays(7);
            
            await _context.SaveChangesAsync();
            
            return authResponse;
        }

        public async Task<AuthResponse?> RefreshTokenAsync(string refreshToken)
        {
            var student = await _context.Students
                .FirstOrDefaultAsync(s => s.RefreshToken == refreshToken && 
                                    s.RefreshTokenExpiryTime > DateTime.UtcNow);

            if (student == null)
            {
                return null;
            }

            var authResponse = GenerateTokens(student);
            
            // Update refresh token
            student.RefreshToken = authResponse.RefreshToken;
            student.RefreshTokenExpiryTime = DateTime.UtcNow.AddDays(7);
            
            await _context.SaveChangesAsync();
            
            return authResponse;
        }

        public async Task<bool> RevokeTokenAsync(string refreshToken)
        {
            var student = await _context.Students
                .FirstOrDefaultAsync(s => s.RefreshToken == refreshToken);

            if (student == null)
            {
                return false;
            }

            student.RefreshToken = null;
            student.RefreshTokenExpiryTime = null;
            
            await _context.SaveChangesAsync();
            
            return true;
        }

        public async Task<Student?> GetCurrentUserAsync(ClaimsPrincipal user)
        {
            var studentIdClaim = user.FindFirst(ClaimTypes.NameIdentifier);
            if (studentIdClaim == null || !int.TryParse(studentIdClaim.Value, out int studentId))
            {
                return null;
            }

            return await _context.Students.FindAsync(studentId);
        }

        private AuthResponse GenerateTokens(Student student)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration["Jwt:Secret"] ?? "your-secret-key-here");
            var tokenExpiry = DateTime.UtcNow.AddHours(2);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.NameIdentifier, student.StudentId.ToString()),
                    new Claim(ClaimTypes.Email, student.Email),
                    new Claim(ClaimTypes.Role, student.Role),
                    new Claim("StudentNumber", student.StudentNumber),
                    new Claim("FullName", student.FullName)
                }),
                Expires = tokenExpiry,
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                Issuer = _configuration["Jwt:Issuer"] ?? "student-portal",
                Audience = _configuration["Jwt:Audience"] ?? "student-portal-users"
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            var refreshToken = GenerateRefreshToken();

            return new AuthResponse
            {
                Token = tokenHandler.WriteToken(token),
                RefreshToken = refreshToken,
                Expiration = tokenExpiry,
                User = new StudentInfo
                {
                    StudentId = student.StudentId,
                    FirstName = student.FirstName,
                    LastName = student.LastName,
                    Email = student.Email,
                    StudentNumber = student.StudentNumber,
                    Role = student.Role
                }
            };
        }

        private string GenerateRefreshToken()
        {
            var randomNumber = new byte[32];
            using (var rng = System.Security.Cryptography.RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber);
            }
        }
    }
}