using System.ComponentModel.DataAnnotations;

namespace StudentPortal.Models
{
    public class Course
    {
        [Key]
        public int CourseId { get; set; }
        
        [Required]
        [StringLength(20)]
        public string CourseCode { get; set; } = string.Empty;
        
        [Required]
        [StringLength(100)]
        public string CourseName { get; set; } = string.Empty;
        
        [StringLength(500)]
        public string Description { get; set; } = string.Empty;
        
        [Required]
        [StringLength(50)]
        public string Department { get; set; } = string.Empty;
        
        [Required]
        [StringLength(50)]
        public string Instructor { get; set; } = string.Empty;
        
        public int Credits { get; set; }
        
        public int MaxCapacity { get; set; }
        
        public int CurrentEnrollment { get; set; }
        
        [StringLength(20)]
        public string Schedule { get; set; } = string.Empty; // e.g., "MWF 10:00-10:50"
        
        [StringLength(50)]
        public string Location { get; set; } = string.Empty;
        
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        
        [StringLength(20)]
        public string Semester { get; set; } = string.Empty; // Fall 2024, Spring 2025
        
        [StringLength(20)]
        public string Status { get; set; } = "Open"; // Open, Closed, Cancelled
        
        public decimal Prerequisites { get; set; } // Minimum GPA required
        
        // Navigation properties
        public virtual ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
        public virtual ICollection<Grade> Grades { get; set; } = new List<Grade>();
        
        // Computed properties
        public int AvailableSeats => MaxCapacity - CurrentEnrollment;
        public bool IsFull => CurrentEnrollment >= MaxCapacity;
        public string CourseInfo => $"{CourseCode} - {CourseName}";
        public string Duration => $"{StartDate:MMM dd} - {EndDate:MMM dd, yyyy}";
    }
}