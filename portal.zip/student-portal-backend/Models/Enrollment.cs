using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StudentPortal.Models
{
    public class Enrollment
    {
        [Key]
        public int EnrollmentId { get; set; }
        
        [Required]
        [ForeignKey("Student")]
        public int StudentId { get; set; }
        
        [Required]
        [ForeignKey("Course")]
        public int CourseId { get; set; }
        
        public DateTime EnrollmentDate { get; set; }
        
        [StringLength(20)]
        public string Status { get; set; } = "Enrolled"; // Enrolled, Dropped, Completed
        
        public decimal? MidtermGrade { get; set; }
        public decimal? FinalGrade { get; set; }
        
        // Navigation properties
        public virtual Student Student { get; set; } = null!;
        public virtual Course Course { get; set; } = null!;
        
        // Computed properties
        public string Semester => Course?.Semester ?? string.Empty;
        public string AcademicYear => EnrollmentDate.Year.ToString();
        public bool IsCurrent => Status == "Enrolled" && Course?.EndDate >= DateTime.Now;
        public decimal? CurrentGrade => FinalGrade ?? MidtermGrade;
    }
}