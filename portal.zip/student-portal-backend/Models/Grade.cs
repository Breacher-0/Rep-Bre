using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StudentPortal.Models
{
    public class Grade
    {
        [Key]
        public int GradeId { get; set; }
        
        [Required]
        [ForeignKey("Student")]
        public int StudentId { get; set; }
        
        [Required]
        [ForeignKey("Course")]
        public int CourseId { get; set; }
        
        [Required]
        [StringLength(50)]
        public string AssignmentType { get; set; } = string.Empty; // Quiz, Midterm, Final, Project, Homework
        
        [Required]
        [StringLength(100)]
        public string AssignmentName { get; set; } = string.Empty;
        
        public decimal Score { get; set; }
        public decimal MaxScore { get; set; }
        public decimal Weight { get; set; } // Percentage weight in final grade
        
        public DateTime DateGraded { get; set; }
        
        [StringLength(500)]
        public string? Feedback { get; set; }
        
        // Navigation properties
        public virtual Student Student { get; set; } = null!;
        public virtual Course Course { get; set; } = null!;
        
        // Computed properties
        public decimal Percentage => MaxScore > 0 ? (Score / MaxScore) * 100 : 0;
        public decimal WeightedScore => (Score / MaxScore) * Weight;
        public string LetterGrade => Percentage switch
        {
            >= 90 => "A",
            >= 80 => "B",
            >= 70 => "C",
            >= 60 => "D",
            _ => "F"
        };
        public string GradeDescription => AssignmentType switch
        {
            "Quiz" => $"Quiz: {AssignmentName}",
            "Midterm" => $"Midterm Exam",
            "Final" => $"Final Exam",
            "Project" => $"Project: {AssignmentName}",
            "Homework" => $"Homework: {AssignmentName}",
            _ => $"{AssignmentType}: {AssignmentName}"
        };
    }
}