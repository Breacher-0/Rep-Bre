using System.ComponentModel.DataAnnotations;

namespace StudentPortal.Models
{
    public class Student
    {
        [Key]
        public int StudentId { get; set; }
        
        [Required]
        [StringLength(50)]
        public string FirstName { get; set; } = string.Empty;
        
        [Required]
        [StringLength(50)]
        public string LastName { get; set; } = string.Empty;
        
        [Required]
        [EmailAddress]
        [StringLength(100)]
        public string Email { get; set; } = string.Empty;
        
        [Required]
        [StringLength(20)]
        public string StudentNumber { get; set; } = string.Empty;
        
        [StringLength(20)]
        public string Phone { get; set; } = string.Empty;
        
        public DateTime DateOfBirth { get; set; }
        
        [StringLength(200)]
        public string Address { get; set; } = string.Empty;
        
        public DateTime EnrollmentDate { get; set; }
        
        [StringLength(50)]
        public string Major { get; set; } = string.Empty;
        
        public decimal GPA { get; set; }
        
        public int CreditsCompleted { get; set; }
        
        [StringLength(20)]
        public string Status { get; set; } = "Active"; // Active, Graduated, Suspended
        
        // Navigation properties
        public virtual ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
        public virtual ICollection<Grade> Grades { get; set; } = new List<Grade>();
        
        // Authentication
        [Required]
        public string PasswordHash { get; set; } = string.Empty;
        
        public string? RefreshToken { get; set; }
        public DateTime? RefreshTokenExpiryTime { get; set; }
        
        [StringLength(50)]
        public string Role { get; set; } = "Student";
        
        // Computed properties
        public string FullName => $"{FirstName} {LastName}";
        public string AcademicStanding => GPA switch
        {
            >= 3.5m => "Excellent",
            >= 3.0m => "Good",
            >= 2.0m => "Satisfactory",
            _ => "Unsatisfactory"
        };
    }
}