using Microsoft.EntityFrameworkCore;
using StudentPortal.Models;

namespace StudentPortal.Data
{
    public class StudentPortalContext : DbContext
    {
        public StudentPortalContext(DbContextOptions<StudentPortalContext> options)
            : base(options)
        {
        }

        public DbSet<Student> Students { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Enrollment> Enrollments { get; set; }
        public DbSet<Grade> Grades { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Student configurations
            modelBuilder.Entity<Student>(entity =>
            {
                entity.HasIndex(e => e.Email).IsUnique();
                entity.HasIndex(e => e.StudentNumber).IsUnique();
                
                entity.Property(e => e.GPA)
                    .HasPrecision(3, 2)
                    .HasDefaultValue(0.00m);
                    
                entity.Property(e => e.Status)
                    .HasDefaultValue("Active");
            });

            // Course configurations
            modelBuilder.Entity<Course>(entity =>
            {
                entity.HasIndex(e => e.CourseCode).IsUnique();
                
                entity.Property(e => e.Prerequisites)
                    .HasPrecision(3, 2)
                    .HasDefaultValue(0.00m);
                    
                entity.Property(e => e.Status)
                    .HasDefaultValue("Open");
            });

            // Enrollment configurations
            modelBuilder.Entity<Enrollment>(entity =>
            {
                entity.HasKey(e => e.EnrollmentId);
                
                entity.HasOne(e => e.Student)
                    .WithMany(s => s.Enrollments)
                    .HasForeignKey(e => e.StudentId)
                    .OnDelete(DeleteBehavior.Cascade);
                    
                entity.HasOne(e => e.Course)
                    .WithMany(c => c.Enrollments)
                    .HasForeignKey(e => e.CourseId)
                    .OnDelete(DeleteBehavior.Cascade);
                    
                entity.Property(e => e.Status)
                    .HasDefaultValue("Enrolled");
            });

            // Grade configurations
            modelBuilder.Entity<Grade>(entity =>
            {
                entity.HasKey(g => g.GradeId);
                
                entity.HasOne(g => g.Student)
                    .WithMany(s => s.Grades)
                    .HasForeignKey(g => g.StudentId)
                    .OnDelete(DeleteBehavior.Cascade);
                    
                entity.HasOne(g => g.Course)
                    .WithMany(c => c.Grades)
                    .HasForeignKey(g => g.CourseId)
                    .OnDelete(DeleteBehavior.Cascade);
                    
                entity.Property(g => g.Weight)
                    .HasPrecision(5, 2);
            });

            // Seed initial data
            SeedData(modelBuilder);
        }

        private void SeedData(ModelBuilder modelBuilder)
        {
            // Seed Students
            var students = new List<Student>
            {
                new Student
                {
                    StudentId = 1,
                    FirstName = "John",
                    LastName = "Doe",
                    Email = "john.doe@university.edu",
                    StudentNumber = "STU2024001",
                    Phone = "555-0101",
                    DateOfBirth = new DateTime(2002, 5, 15),
                    Address = "123 Main St, City, State 12345",
                    EnrollmentDate = new DateTime(2024, 1, 15),
                    Major = "Computer Science",
                    GPA = 3.75m,
                    CreditsCompleted = 45,
                    Status = "Active",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("password123"),
                    Role = "Student"
                },
                new Student
                {
                    StudentId = 2,
                    FirstName = "Jane",
                    LastName = "Smith",
                    Email = "jane.smith@university.edu",
                    StudentNumber = "STU2024002",
                    Phone = "555-0102",
                    DateOfBirth = new DateTime(2001, 8, 22),
                    Address = "456 Oak Ave, City, State 12345",
                    EnrollmentDate = new DateTime(2024, 1, 15),
                    Major = "Software Engineering",
                    GPA = 3.85m,
                    CreditsCompleted = 42,
                    Status = "Active",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("password123"),
                    Role = "Student"
                },
                new Student
                {
                    StudentId = 3,
                    FirstName = "Michael",
                    LastName = "Johnson",
                    Email = "michael.johnson@university.edu",
                    StudentNumber = "STU2024003",
                    Phone = "555-0103",
                    DateOfBirth = new DateTime(2000, 12, 10),
                    Address = "789 Pine St, City, State 12345",
                    EnrollmentDate = new DateTime(2023, 8, 20),
                    Major = "Information Technology",
                    GPA = 3.45m,
                    CreditsCompleted = 78,
                    Status = "Active",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("password123"),
                    Role = "Student"
                }
            };

            modelBuilder.Entity<Student>().HasData(students);

            // Seed Courses
            var courses = new List<Course>
            {
                new Course
                {
                    CourseId = 1,
                    CourseCode = "CS101",
                    CourseName = "Introduction to Computer Science",
                    Description = "Fundamental concepts of computer science and programming",
                    Department = "Computer Science",
                    Instructor = "Dr. Alan Turing",
                    Credits = 3,
                    MaxCapacity = 30,
                    CurrentEnrollment = 25,
                    Schedule = "MWF 10:00-10:50",
                    Location = "Tech Building 101",
                    StartDate = new DateTime(2024, 1, 15),
                    EndDate = new DateTime(2024, 5, 15),
                    Semester = "Spring 2024",
                    Status = "Open",
                    Prerequisites = 0.00m
                },
                new Course
                {
                    CourseId = 2,
                    CourseCode = "CS201",
                    CourseName = "Data Structures and Algorithms",
                    Description = "Advanced programming concepts with focus on data structures",
                    Department = "Computer Science",
                    Instructor = "Dr. Ada Lovelace",
                    Credits = 4,
                    MaxCapacity = 25,
                    CurrentEnrollment = 22,
                    Schedule = "TTh 14:00-15:15",
                    Location = "Tech Building 205",
                    StartDate = new DateTime(2024, 1, 15),
                    EndDate = new DateTime(2024, 5, 15),
                    Semester = "Spring 2024",
                    Status = "Open",
                    Prerequisites = 2.50m
                },
                new Course
                {
                    CourseId = 3,
                    CourseCode = "MATH150",
                    CourseName = "Calculus I",
                    Description = "Differential calculus and applications",
                    Department = "Mathematics",
                    Instructor = "Dr. Isaac Newton",
                    Credits = 4,
                    MaxCapacity = 35,
                    CurrentEnrollment = 30,
                    Schedule = "MWF 09:00-09:50",
                    Location = "Math Building 101",
                    StartDate = new DateTime(2024, 1, 15),
                    EndDate = new DateTime(2024, 5, 15),
                    Semester = "Spring 2024",
                    Status = "Open",
                    Prerequisites = 0.00m
                },
                new Course
                {
                    CourseId = 4,
                    CourseCode = "ENG101",
                    CourseName = "English Composition",
                    Description = "Academic writing and critical thinking",
                    Department = "English",
                    Instructor = "Prof. William Shakespeare",
                    Credits = 3,
                    MaxCapacity = 28,
                    CurrentEnrollment = 26,
                    Schedule = "TTh 11:00-12:15",
                    Location = "Liberal Arts 201",
                    StartDate = new DateTime(2024, 1, 15),
                    EndDate = new DateTime(2024, 5, 15),
                    Semester = "Spring 2024",
                    Status = "Open",
                    Prerequisites = 0.00m
                }
            };

            modelBuilder.Entity<Course>().HasData(courses);

            // Seed Enrollments
            var enrollments = new List<Enrollment>
            {
                new Enrollment
                {
                    EnrollmentId = 1,
                    StudentId = 1,
                    CourseId = 1,
                    EnrollmentDate = new DateTime(2024, 1, 15),
                    Status = "Enrolled"
                },
                new Enrollment
                {
                    EnrollmentId = 2,
                    StudentId = 1,
                    CourseId = 2,
                    EnrollmentDate = new DateTime(2024, 1, 15),
                    Status = "Enrolled"
                },
                new Enrollment
                {
                    EnrollmentId = 3,
                    StudentId = 2,
                    CourseId = 1,
                    EnrollmentDate = new DateTime(2024, 1, 15),
                    Status = "Enrolled"
                },
                new Enrollment
                {
                    EnrollmentId = 4,
                    StudentId = 2,
                    CourseId = 3,
                    EnrollmentDate = new DateTime(2024, 1, 15),
                    Status = "Enrolled"
                },
                new Enrollment
                {
                    EnrollmentId = 5,
                    StudentId = 3,
                    CourseId = 2,
                    EnrollmentDate = new DateTime(2024, 1, 15),
                    Status = "Enrolled"
                },
                new Enrollment
                {
                    EnrollmentId = 6,
                    StudentId = 3,
                    CourseId = 4,
                    EnrollmentDate = new DateTime(2024, 1, 15),
                    Status = "Enrolled"
                }
            };

            modelBuilder.Entity<Enrollment>().HasData(enrollments);

            // Seed Grades
            var grades = new List<Grade>
            {
                new Grade
                {
                    GradeId = 1,
                    StudentId = 1,
                    CourseId = 1,
                    AssignmentType = "Quiz",
                    AssignmentName = "Quiz 1",
                    Score = 85,
                    MaxScore = 100,
                    Weight = 10,
                    DateGraded = new DateTime(2024, 2, 1),
                    Feedback = "Good understanding of basic concepts"
                },
                new Grade
                {
                    GradeId = 2,
                    StudentId = 1,
                    CourseId = 1,
                    AssignmentType = "Midterm",
                    AssignmentName = "Midterm Exam",
                    Score = 88,
                    MaxScore = 100,
                    Weight = 30,
                    DateGraded = new DateTime(2024, 3, 15),
                    Feedback = "Strong performance on programming concepts"
                },
                new Grade
                {
                    GradeId = 3,
                    StudentId = 2,
                    CourseId = 1,
                    AssignmentType = "Quiz",
                    AssignmentName = "Quiz 1",
                    Score = 92,
                    MaxScore = 100,
                    Weight = 10,
                    DateGraded = new DateTime(2024, 2, 1),
                    Feedback = "Excellent work!"
                },
                new Grade
                {
                    GradeId = 4,
                    StudentId = 2,
                    CourseId = 3,
                    AssignmentType = "Homework",
                    AssignmentName = "Homework 1",
                    Score = 78,
                    MaxScore = 100,
                    Weight = 15,
                    DateGraded = new DateTime(2024, 2, 5),
                    Feedback = "Need to show more work on derivatives"
                },
                new Grade
                {
                    GradeId = 5,
                    StudentId = 3,
                    CourseId = 2,
                    AssignmentType = "Project",
                    AssignmentName = "Linked List Implementation",
                    Score = 95,
                    MaxScore = 100,
                    Weight = 25,
                    DateGraded = new DateTime(2024, 2, 20),
                    Feedback = "Outstanding implementation with proper error handling"
                }
            };

            modelBuilder.Entity<Grade>().HasData(grades);
        }
    }
}