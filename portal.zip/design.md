# Portfolio Website Design Style Guide

## Design Philosophy

### Visual Language
- **Modern Minimalism**: Clean, uncluttered layouts with purposeful white space
- **Professional Elegance**: Sophisticated design suitable for tech industry applications
- **Tech-Focused Aesthetic**: Subtle tech-inspired elements without being overly futuristic
- **Personal Brand**: Professional yet approachable, reflecting a full-stack developer's versatility

### Color Palette
- **Primary Colors**: 
  - Deep Navy (#1a1a2e) - Professional, trustworthy
  - Soft Blue (#4a90e2) - Tech-focused, modern
  - Light Gray (#f8f9fa) - Clean, minimal background
- **Accent Colors**:
  - Emerald Green (#10b981) - Success, growth
  - Warm Orange (#f59e0b) - Energy, creativity
- **Dark Theme Variants**:
  - Charcoal (#2d3748) - Dark background
  - Light Blue (#63b3ed) - Accent in dark mode
  - Soft White (#f7fafc) - Text in dark mode

### Typography
- **Primary Font**: "Inter" - Modern, highly legible sans-serif
- **Secondary Font**: "JetBrains Mono" - For code snippets and technical content
- **Hierarchy**:
  - H1: 3.5rem, bold, letter-spacing: -0.02em
  - H2: 2.5rem, semibold
  - H3: 1.875rem, medium
  - Body: 1rem, regular, line-height: 1.6
  - Small: 0.875rem, regular

## Visual Effects & Animations

### Core Animation Libraries
- **Anime.js**: Smooth micro-interactions and element animations
- **Typed.js**: Typewriter effect for hero section
- **Splitting.js**: Text reveal animations
- **ECharts.js**: Skills visualization charts
- **Pixi.js**: Subtle particle effects in hero background

### Animation Effects
1. **Hero Section**:
   - Typewriter animation for name and title
   - Subtle particle background using Pixi.js
   - Floating elements with gentle motion
   - Gradient text animation on name

2. **Skills Section**:
   - Staggered fade-in for skill cards
   - Hover effects with 3D tilt and shadow
   - Progress bar animations for skill levels
   - Icon animations on hover

3. **Experience Timeline**:
   - Scroll-triggered timeline animations
   - Card lift effects on hover
   - Smooth expand/collapse transitions
   - Dot connection animations

4. **General Interactions**:
   - Smooth theme transitions
   - Button hover effects with color morphing
   - Image zoom effects on hover
   - Form field focus animations

### Background & Layout
- **Consistent Background**: Subtle gradient mesh using CSS custom properties
- **Section Differentiation**: Subtle geometric shapes and patterns
- **No Harsh Transitions**: Smooth color transitions between sections
- **Responsive Grid**: CSS Grid with Tailwind utilities

## Component Design

### Navigation Bar
- **Style**: Glassmorphism effect with backdrop blur
- **Position**: Fixed top with smooth scroll offset
- **Animation**: Slide-in on page load
- **Mobile**: Hamburger menu with smooth slide animation

### Hero Section
- **Layout**: Centered content with offset for navigation
- **Background**: Animated gradient mesh with particles
- **Typography**: Large, bold headings with gradient effects
- **CTA Buttons**: Rounded, with hover animations

### Skill Cards
- **Design**: Rounded corners (12px), subtle shadows
- **Hover**: Lift effect with increased shadow and slight rotation
- **Icons**: Custom SVG icons with color-coded categories
- **Layout**: Grid layout with responsive breakpoints

### Experience Cards
- **Style**: Timeline design with connecting lines
- **Animation**: Reveal on scroll with staggered timing
- **Hover**: Subtle scale and shadow effects
- **Content**: Expandable sections with smooth transitions

### Contact Form
- **Fields**: Rounded inputs with floating labels
- **Validation**: Real-time feedback with color coding
- **Button**: Gradient background with loading states
- **Success**: Animated checkmark and confirmation message

## Responsive Design
- **Mobile-First**: Design starts with mobile layout
- **Breakpoints**: 
  - Mobile: 320px - 768px
  - Tablet: 768px - 1024px
  - Desktop: 1024px+
- **Touch Targets**: Minimum 44px for mobile interactions
- **Typography Scale**: Responsive font sizes using clamp()

## Accessibility
- **Color Contrast**: Minimum 4.5:1 ratio for all text
- **Focus States**: Clear focus indicators for keyboard navigation
- **Screen Readers**: Proper ARIA labels and semantic HTML
- **Motion**: Respects user's motion preferences

## Performance
- **Optimized Assets**: Compressed images and SVGs
- **Lazy Loading**: Images load as needed
- **CSS Optimization**: Critical CSS inlined, non-critical deferred
- **Animation Performance**: GPU-accelerated transforms only